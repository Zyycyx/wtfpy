# __main__.py

from WtfPy import *

def main():
	pass

if __name__ == "__main__":
	main()
